"use client"

import { useEffect, useRef, useState } from "react"
import { cn } from "@/lib/utils"

const fullStackSkills = [
  { name: "React / Next.js", level: 95 },
  { name: "TypeScript", level: 90 },
  { name: "Node.js / Express", level: 88 },
  { name: "Python", level: 80 },
  { name: "PostgreSQL / MongoDB", level: 85 },
]

const frameworksAndTools = [
  { name: "Tailwind CSS", level: 95 },
  { name: "Vue.js / Nuxt", level: 75 },
  { name: "Docker", level: 70 },
  { name: "Git / GitHub", level: 90 },
  { name: "REST API / GraphQL", level: 88 },
]

const cyberSecuritySkills = [
  { name: "Securite Web (OWASP)", level: 70 },
  { name: "Cryptographie", level: 65 },
  { name: "Pentest Basics", level: 60 },
  { name: "Linux / Bash", level: 75 },
]

const tools = [
  { name: "VS Code", icon: "VS", color: "from-blue-500/20 to-indigo-500/20" },
  { name: "Figma", icon: "Fi", color: "from-purple-500/20 to-pink-500/20" },
  { name: "Docker", icon: "Do", color: "from-blue-500/20 to-cyan-500/20" },
  { name: "Vercel", icon: "Ve", color: "from-zinc-500/20 to-slate-500/20" },
  { name: "AWS", icon: "AW", color: "from-amber-500/20 to-yellow-500/20" },
  { name: "Linux", icon: "Li", color: "from-yellow-500/20 to-orange-500/20" },
  { name: "GitHub", icon: "Gh", color: "from-gray-500/20 to-zinc-500/20" },
  { name: "Postman", icon: "Po", color: "from-orange-500/20 to-red-500/20" },
]

const frameworks = [
  "Next.js", "React", "Vue.js", "Nuxt", "Express", "FastAPI", 
  "Django", "Prisma", "Tailwind", "Bootstrap", "Socket.io", "GraphQL"
]

function SkillBar({ name, level, delay = 0, color = "from-primary to-accent" }: { name: string; level: number; delay?: number; color?: string }) {
  const [width, setWidth] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const [hasAnimated, setHasAnimated] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true)
          setTimeout(() => setWidth(level), delay)
        }
      },
      { threshold: 0.5 }
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [level, delay, hasAnimated])

  return (
    <div ref={ref} className="mb-5 group">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{name}</span>
        <span className="text-sm text-muted-foreground font-mono">{level}%</span>
      </div>
      <div className="h-2.5 bg-secondary rounded-full overflow-hidden relative">
        <div 
          className={cn("h-full bg-gradient-to-r rounded-full transition-all duration-1000 ease-out relative", color)}
          style={{ width: `${width}%` }}
        >
          <span className="absolute right-0 top-0 h-full w-2 bg-white/40 animate-pulse rounded-full" />
        </div>
        {/* Animated glow */}
        <div 
          className="absolute top-0 left-0 h-full bg-primary/20 blur-sm rounded-full transition-all duration-1000"
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  )
}

function CircularProgress({ level, label, delay = 0 }: { level: number; label: string; delay?: number }) {
  const [progress, setProgress] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const [hasAnimated, setHasAnimated] = useState(false)
  
  const circumference = 2 * Math.PI * 45
  const strokeDashoffset = circumference - (progress / 100) * circumference

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true)
          setTimeout(() => {
            const duration = 1500
            const steps = 60
            const increment = level / steps
            let current = 0
            const timer = setInterval(() => {
              current += increment
              if (current >= level) {
                setProgress(level)
                clearInterval(timer)
              } else {
                setProgress(Math.floor(current))
              }
            }, duration / steps)
          }, delay)
        }
      },
      { threshold: 0.5 }
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [level, delay, hasAnimated])

  return (
    <div ref={ref} className="flex flex-col items-center group">
      <div className="relative w-28 h-28">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="56"
            cy="56"
            r="45"
            stroke="currentColor"
            strokeWidth="8"
            fill="none"
            className="text-secondary"
          />
          <circle
            cx="56"
            cy="56"
            r="45"
            stroke="url(#gradient)"
            strokeWidth="8"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-1000 ease-out"
          />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="var(--primary)" />
              <stop offset="100%" stopColor="var(--accent)" />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-2xl font-bold text-foreground">{progress}%</span>
        </div>
      </div>
      <span className="mt-3 text-sm text-muted-foreground text-center group-hover:text-foreground transition-colors">{label}</span>
    </div>
  )
}

function useInView(ref: React.RefObject<HTMLElement | null>) {
  const [isInView, setIsInView] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setIsInView(entry.isIntersecting),
      { threshold: 0.1 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [ref])
  
  return isInView
}

export function Skills() {
  const sectionRef = useRef<HTMLElement>(null)
  const isInView = useInView(sectionRef)

  return (
    <section ref={sectionRef} id="skills" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-primary/5" />
      <div className="absolute top-1/4 -right-32 w-64 h-64 bg-primary/10 rounded-full blur-[100px] animate-pulse" />
      <div className="absolute bottom-1/4 -left-32 w-64 h-64 bg-accent/10 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: "1s" }} />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className={cn(
            "text-center mb-16 transition-all duration-700",
            isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          )}>
            <p className="text-primary font-medium mb-2 tracking-wider uppercase text-sm">
              Ce que je maitrise
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Competences & Technologies
            </h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full" />
          </div>
          
          {/* Skills Grid - Progress Bars */}
          <div className="grid lg:grid-cols-2 gap-8 mb-16">
            {/* Full-Stack Skills */}
            <div className={cn(
              "bg-card rounded-xl p-8 border border-border hover:border-primary/30 transition-all duration-500 hover:shadow-xl hover:shadow-primary/5",
              isInView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"
            )} style={{ transitionDelay: "200ms" }}>
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                <span className="w-3 h-3 bg-primary rounded-full animate-pulse" />
                Developpement Full-Stack
              </h3>
              {fullStackSkills.map((skill, index) => (
                <SkillBar 
                  key={skill.name} 
                  name={skill.name} 
                  level={skill.level} 
                  delay={index * 100}
                />
              ))}
            </div>
            
            {/* Frameworks & Tools */}
            <div className={cn(
              "bg-card rounded-xl p-8 border border-border hover:border-accent/30 transition-all duration-500 hover:shadow-xl hover:shadow-accent/5",
              isInView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
            )} style={{ transitionDelay: "400ms" }}>
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                <span className="w-3 h-3 bg-accent rounded-full animate-pulse" />
                Frameworks & Outils
              </h3>
              {frameworksAndTools.map((skill, index) => (
                <SkillBar 
                  key={skill.name} 
                  name={skill.name} 
                  level={skill.level} 
                  delay={index * 100}
                  color="from-accent to-primary"
                />
              ))}
            </div>
          </div>

          {/* Circular Progress - Cybersecurity */}
          <div className={cn(
            "bg-card rounded-xl p-8 border border-border mb-16 transition-all duration-700",
            isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
          )} style={{ transitionDelay: "500ms" }}>
            <h3 className="text-xl font-bold text-foreground mb-8 text-center flex items-center justify-center gap-2">
              <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
              Cybersecurite (En formation)
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 justify-items-center">
              {cyberSecuritySkills.map((skill, index) => (
                <CircularProgress 
                  key={skill.name}
                  level={skill.level}
                  label={skill.name}
                  delay={index * 150}
                />
              ))}
            </div>
          </div>
          
          {/* Tools & Technologies Grid */}
          <div className={cn(
            "bg-card rounded-xl p-8 border border-border transition-all duration-700 mb-12",
            isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
          )} style={{ transitionDelay: "600ms" }}>
            <h3 className="text-xl font-bold text-foreground mb-8 text-center">
              Outils que j&apos;utilise
            </h3>
            <div className="flex flex-wrap justify-center gap-4">
              {tools.map((tool, index) => (
                <div 
                  key={tool.name}
                  className={cn(
                    "group relative flex flex-col items-center justify-center p-4 rounded-xl bg-gradient-to-br transition-all duration-300 cursor-default min-w-[100px] hover:scale-110 hover:shadow-lg",
                    tool.color
                  )}
                  style={{ 
                    transitionDelay: `${700 + index * 50}ms`,
                    opacity: isInView ? 1 : 0,
                    transform: isInView ? "translateY(0)" : "translateY(20px)"
                  }}
                >
                  <div className="w-12 h-12 rounded-lg bg-background/50 flex items-center justify-center mb-2 group-hover:bg-background/80 transition-colors">
                    <span className="text-lg font-bold text-primary">{tool.icon}</span>
                  </div>
                  <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                    {tool.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Frameworks Tags */}
          <div className={cn(
            "text-center transition-all duration-700",
            isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          )} style={{ transitionDelay: "800ms" }}>
            <p className="text-muted-foreground mb-6">
              Frameworks et librairies que je maitrise
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {frameworks.map((tech, index) => (
                <span 
                  key={tech}
                  className="px-4 py-2 bg-card border border-border rounded-full text-sm text-muted-foreground hover:border-primary/50 hover:text-foreground hover:scale-105 hover:bg-primary/5 transition-all cursor-default"
                  style={{ transitionDelay: `${900 + index * 30}ms` }}
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
