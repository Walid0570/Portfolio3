"use client"

import { useRef, useState, useEffect } from "react"
import { Briefcase, GraduationCap, Award } from "lucide-react"
import { cn } from "@/lib/utils"

const experiences = [
  {
    type: "work",
    title: "Developpeur Full-Stack Freelance",
    company: "Independant",
    period: "2023 - Present",
    description: "Developpement d'applications web sur mesure pour des clients varies. Specialisation en React, Next.js et Node.js avec integration d'IA.",
    technologies: ["React", "Next.js", "Node.js", "PostgreSQL", "OpenAI"],
  },
  {
    type: "work",
    title: "Creation de MySécuriTech",
    company: "Projet Client",
    period: "2024",
    description: "Conception et developpement complet du site vitrine pour une entreprise de securite. Design moderne et optimise SEO.",
    technologies: ["Next.js", "TypeScript", "Tailwind CSS", "Framer Motion"],
  },
  {
    type: "education",
    title: "BTS SIO Option SLAM",
    company: "Lycee Simone Weil, Saint-Priest en Jarez",
    period: "2022 - 2024",
    description: "Services Informatiques aux Organisations, option Solutions Logicielles et Applications Metiers. Formation complete en developpement d'applications et gestion de projets informatiques.",
    technologies: ["Java", "PHP", "SQL", "HTML/CSS", "JavaScript"],
  },
  {
    type: "education",
    title: "Bac Pro Systeme Numerique RISC",
    company: "Lycee Pierre Desgranges, Andrezieux-Boutheon",
    period: "2019 - 2022",
    description: "Baccalaureat Professionnel Systemes Numeriques option Reseaux Informatiques et Systemes Communicants. Formation aux fondamentaux des reseaux, systemes et maintenance informatique.",
    technologies: ["Reseaux", "Systemes", "Maintenance", "Electronique"],
  },
  {
    type: "certification",
    title: "Certifications FreeCodeCamp",
    company: "FreeCodeCamp.org",
    period: "2023",
    description: "Responsive Web Design, JavaScript Algorithms and Data Structures, Front End Development Libraries. Apprentissage approfondi des technologies web modernes.",
    technologies: ["HTML/CSS", "JavaScript", "React", "Algorithmes"],
  },
  {
    type: "certification",
    title: "Formation Cybersecurite",
    company: "En cours",
    period: "2024 - Present",
    description: "Apprentissage des fondamentaux de la cybersecurite : tests de penetration, securite des applications web, cryptographie et bonnes pratiques OWASP.",
    technologies: ["OWASP", "Pentest", "Cryptographie", "Linux"],
  },
]

function useInView(ref: React.RefObject<HTMLElement | null>) {
  const [isInView, setIsInView] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setIsInView(entry.isIntersecting),
      { threshold: 0.1 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [ref])
  
  return isInView
}

export function Experience() {
  const sectionRef = useRef<HTMLElement>(null)
  const isInView = useInView(sectionRef)

  const getIcon = (type: string) => {
    switch (type) {
      case "work":
        return Briefcase
      case "education":
        return GraduationCap
      case "certification":
        return Award
      default:
        return Briefcase
    }
  }

  const getIconColor = (type: string) => {
    switch (type) {
      case "work":
        return "bg-primary/10 group-hover:bg-primary/20 text-primary"
      case "education":
        return "bg-accent/10 group-hover:bg-accent/20 text-accent"
      case "certification":
        return "bg-green-500/10 group-hover:bg-green-500/20 text-green-500"
      default:
        return "bg-primary/10 group-hover:bg-primary/20 text-primary"
    }
  }

  return (
    <section ref={sectionRef} id="experience" className="py-20 lg:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-accent/5 to-transparent" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className={cn(
            "text-center mb-16 transition-all duration-700",
            isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          )}>
            <p className="text-primary font-medium mb-2 tracking-wider uppercase text-sm">
              Mon Parcours
            </p>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Experience & Formation
            </h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full" />
          </div>
          
          {/* Timeline */}
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-accent to-green-500 md:-translate-x-0.5" />
            
            {experiences.map((exp, index) => {
              const IconComponent = getIcon(exp.type)
              return (
                <div 
                  key={index}
                  className={cn(
                    "relative mb-12 last:mb-0 transition-all duration-700",
                    "md:w-1/2",
                    index % 2 === 0 ? "md:pr-12 md:ml-0" : "md:pl-12 md:ml-auto",
                    isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
                  )}
                  style={{ transitionDelay: `${200 + index * 150}ms` }}
                >
                  {/* Timeline Dot */}
                  <div 
                    className={cn(
                      "absolute left-8 md:left-auto w-4 h-4 bg-primary rounded-full border-4 border-background -translate-x-1/2 z-10 shadow-lg shadow-primary/50",
                      index % 2 === 0 ? "md:right-0 md:translate-x-1/2" : "md:left-0 md:-translate-x-1/2"
                    )}
                  >
                    <span className="absolute inset-0 bg-primary rounded-full animate-ping opacity-25" />
                  </div>
                  
                  {/* Content Card */}
                  <div className="ml-16 md:ml-0 bg-card rounded-xl p-6 border border-border hover:border-primary/50 transition-all duration-500 hover:shadow-xl hover:shadow-primary/5 group hover:-translate-y-1">
                    <div className="flex items-center gap-3 mb-4">
                      <div className={cn(
                        "w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-300 group-hover:scale-110",
                        getIconColor(exp.type)
                      )}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <span className="text-sm text-muted-foreground bg-secondary/50 px-3 py-1 rounded-full">{exp.period}</span>
                    </div>
                    
                    <h3 className="text-lg font-bold text-foreground mb-1 group-hover:text-primary transition-colors">
                      {exp.title}
                    </h3>
                    <p className="text-primary text-sm mb-3">{exp.company}</p>
                    <p className="text-muted-foreground text-sm mb-4">
                      {exp.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2">
                      {exp.technologies.map((tech) => (
                        <span 
                          key={tech}
                          className="text-xs px-2 py-1 bg-secondary/80 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
